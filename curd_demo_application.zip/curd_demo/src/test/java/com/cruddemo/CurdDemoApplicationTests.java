package com.cruddemo;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cruddemo.entities.Student;
import com.cruddemo.repository.StudentRepository;
// Hibernate Internally Generate SQL Query.
@SpringBootTest
class CurdDemo1ApplicationTests {
	@Autowired  
/* when we add this we are telling the springboot this is repository layer 
	  your required object address put into it*/
	private StudentRepository studentRepo;
	//After the object is created we are getting save method.

	@Test
	void saveOneStudentRecord() {
		//System.out.println(studentRepo);
		Student s1=new Student();
		s1.setName("partha");
		s1.setCourse("testing");
		s1.setFee(2000);
		// TO save object s1 to DB 
		studentRepo.save(s1); // this acts like insert Command. then it s1 data move into Db(injected Data)
		// After StuentRepo object is created into then call save  
		//save method will helping me to create a Record. 
		
		}
	   @Test
		void deleteOneStudentRecord() {
			  studentRepo.deleteById(7L);
	// when you declared a Id Value it should be Written down with long (L) mandetory.
		}
	   @Test
	    void getOneStudentRecord() {
	    	//studentRepo.findById(1L); then we get an object is an Optional
		   Optional<Student> findById = studentRepo.findById(5L);
		   //findbyId.get(); now it is not an optional.
		   Student s = findById.get(); // put the optional Obj into get().
		   System.out.println(s.getId());  // Read the Record.
		   System.out.println(s.getName());
		   System.out.println(s.getFee());
		   System.out.println(s.getCourse());
		   
	   }
@Test
void updateOneStudentRecord() {
	//studentRepo.findById(1L); then we get an object is an Optional
   Optional<Student> findById = studentRepo.findById(5L);
   //findbyId.get(); now it is not an optional.
   Student s = findById.get(); // put the optional Object into get().
   s.setCourse("development"); // What you Want to Update.
   studentRepo.save(s); // Save  the record With object s.
   /* Repository Layer is giving me all of those methods like 
    * save(),deleteById(),findById(),findALL() 
    * these all of those things we are getting from repository Layer
     */
}
@Test
void getAllStudentRecord() {
	Iterable<Student> findAll = studentRepo.findAll(); // we will get All the record.
	//System.out.println(findAll);
	//  if there 10 rows are Happen then we are create 10 Obj. now we need to read the data from database through object.
	for (Student student : findAll) {
		System.out.println(student.getId()); // Using First Object Address.
		System.err.println(student.getName());
		System.out.println(student.getCourse());
		System.out.println(student.getFee());
	}
	
}

}
