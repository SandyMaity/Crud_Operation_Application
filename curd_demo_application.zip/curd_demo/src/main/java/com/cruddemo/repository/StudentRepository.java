package com.cruddemo.repository;

import org.springframework.data.repository.CrudRepository;
// here we import the Spring boot framework into hibernet.
import com.cruddemo.entities.Student;
//The Repository Layer is an Spring Part of your Application.
public interface StudentRepository extends CrudRepository<Student,Long> {
	// here Student is an entity Class. And in DB we have a primary key and those datatype is Long(Wrapper Class).
	// In this line spring boot will perform all crud Operation. 

}
