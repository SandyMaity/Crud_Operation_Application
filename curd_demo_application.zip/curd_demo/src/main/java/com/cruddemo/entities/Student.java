package com.cruddemo.entities;
//This all Something to do with JPA
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//it is implementation on JPA.
@Entity/*I am telling the Springboot that boss this class
object Content you have to push into Database table */
public class Student { // this is an entity class & this class object content should be pushed to database table.
		@Id // this variable of your class is mapped to the primary key of the database table  column. 
		@GeneratedValue(strategy = GenerationType.IDENTITY) 	
		/*Here we are this annotation is used for auto increment purpose.
	 	this one line will auto increment the values.it is while you are used in database where auto increment written down.
		 */
		private long id; // here id is an primary key.
		// For encapsulation purpose we are declared as a private.
		private String name;//whatever is given in database it should matched.
		private String course;
		private int fee;
		// next generate Getters and  setters then encapsulation will be done
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public int getFee() {
			return fee;
		}
		public void setFee(int fee) {
			this.fee = fee;
		}	
}
